package emp;

import java.util.*;

public class Emp {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		
		System.out.println ("Enter Employee id");
		int Id =s.nextInt();
		System.out.println ("Enter Employee Name");
		String Name = s.next();
		System.out.println ("Enter Basic Salary");
		Float sal = s.nextFloat();
		
		Employee e1=new Employee(Id,Name,sal);
		e1.CalcSal();
		e1.print();
	
		
				}

}
