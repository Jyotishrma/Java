package emp;

public class Employee {
	int ID;
	String Name;
	float Salary;
	float basic;
	float hra;
	float da;
	
	Employee(int id, String name, float sal)
	{
		ID=id;
		Name=name;
		basic=sal;
	}

	void print() {
		System.out.println("ID=" + ID);
		System.out.println("Name=" + Name);
		System.out.println("Salary=" + Salary);
		System.out.println("Basic" + basic);
		System.out.println("Da=" + da);
		System.out.println("hra=" + hra);

	}

	void CalcSal() {
		this.da = basic * 15 / 100;
		this.hra = basic * 10 / 100;
		this.Salary = basic + da + hra;
		System.out.println("Employee Id= " + ID);
		System.out.println("Emplyee Name= " + Name);
		System.out.println("Gross Salary= " + Salary);

	}

}
